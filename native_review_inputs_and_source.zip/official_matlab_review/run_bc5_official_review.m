function run_bc5_official_review(review_root)
% Execute only the frozen native diagnostic panel with official ECGDeli v1.1.
% No reference FPT is supplied to detection, and no image is loaded.
% This harness has NOT been run in the environment that prepared the package.
if nargin < 1, review_root = fileparts(mfilename('fullpath')); end
old_path = path;
cleanup = onCleanup(@() path(old_path)); %#ok<NASGU>
official_root = fullfile(review_root, 'official_ecgdeli_v1_1');
addpath(genpath(official_root), '-begin');
expected_entry = fullfile(official_root, 'ECG_Processing', 'Annotate_ECG_Multi.m');
assert(strcmp(which('Annotate_ECG_Multi'), expected_entry), ...
    'A different ECGDeli entry is shadowing the pinned implementation');
contract = jsondecode(fileread(fullfile(review_root, 'review_contract.json')));
input_root = fullfile(review_root, 'matlab_inputs');
output_root = fullfile(review_root, 'matlab_outputs');
if ~exist(output_root, 'dir'), mkdir(output_root); end
modes = {'raw', 'example_filtered'};
assert(isequal(modes(:), cellstr(contract.modes(:))));
status_file = fullfile(output_root, 'official_record_status.csv');
assert(~exist(status_file, 'file'), 'Existing review results retained; use a fresh copy for reruns');
file = fopen(status_file, 'w');
assert(file >= 0, 'Cannot open status ledger');
file_cleanup = onCleanup(@() fclose(file)); %#ok<NASGU>
fprintf(file, 'ecg_id,mode,status,error_identifier,output_file\n');
runtime_version = version;
runtime_release = version('-release');
runtime_toolboxes = ver;
source_commit = contract.source_commit;
save(fullfile(output_root, 'runtime_provenance.mat'), ...
    'runtime_version', 'runtime_release', 'runtime_toolboxes', 'source_commit', '-v7');
for j = 1:numel(contract.ecg_ids)
    ecg_id = double(contract.ecg_ids(j));
    for k = 1:numel(modes)
        mode = modes{k};
        output_name = sprintf('%05d_%s_matlab.mat', ecg_id, mode);
        output_file = fullfile(output_root, output_name);
        assert(~exist(output_file, 'file'), 'Will not overwrite a prior native review output');
        try
            src = load(fullfile(input_root, sprintf('%05d_native_input.mat', ecg_id)));
            fs = double(src.Fs);
            assert(fs == 500 && isequal(size(src.ecg), [5000 12]));
            assert(double(src.ecg_id) == ecg_id && isa(src.ecg, 'double'));
            assert(all(isfinite(src.ecg(:))));
            lead_names = src.lead_names;
            signal = src.ecg;
            if strcmp(mode, 'example_filtered')
                signal = ECG_High_Low_Filter(signal, fs, 1, 40);
                signal = Notch_Filter(signal, fs, 50, 1);
                signal = Isoline_Correction(signal);
            end
            [FPT_MultiChannel, FPT_Cell] = Annotate_ECG_Multi(signal, fs, 'all');
            assert(size(FPT_MultiChannel, 1) >= 2 && size(FPT_MultiChannel, 2) == 13);
            assert(numel(FPT_Cell) == 12);
            for c = 1:numel(FPT_Cell)
                assert(isequal(size(FPT_Cell{c}), size(FPT_MultiChannel)));
            end
            [Timing_feature_12leads, Timing_feature_sync] = ...
                ExtractIntervalFeaturesFromFPT(FPT_Cell, FPT_MultiChannel);
            status = 'SUCCESS';
            error_identifier = ''; error_message = '';
            save(output_file, 'ecg_id', 'mode', 'fs', 'lead_names', ...
                'FPT_MultiChannel', 'FPT_Cell', 'Timing_feature_12leads', ...
                'Timing_feature_sync', 'source_commit', 'runtime_version', ...
                'runtime_release', 'status', 'error_identifier', 'error_message', '-v7');
        catch err
            status = 'FAILED';
            error_identifier = err.identifier;
            error_message = getReport(err, 'extended', 'hyperlinks', 'off');
            fs = 500;
            save(output_file, 'ecg_id', 'mode', 'fs', 'source_commit', ...
                'runtime_version', 'runtime_release', 'status', ...
                'error_identifier', 'error_message', '-v7');
        end
        safe_error = strrep(strrep(error_identifier, ',', '_'), newline, ' ');
        fprintf(file, '%d,%s,%s,%s,%s\n', ecg_id, mode, status, safe_error, output_name);
        fprintf('%d %s %s\n', ecg_id, mode, status);
    end
end
end
